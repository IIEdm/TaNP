import numpy as np
import numpy.random as rand
import os
import sys
import json
# key-user, value-list saving item ids
inter_dict_x = {}
# key-user, value-list saving feedback(0-1)
inter_dict_y = {}

user_list = []
item_list = []

def count_values(dict):
    count_val = 0
    for key, value in dict.items():
        count_val += len(value)
    return count_val

with open('ratings_final.txt', 'r', encoding='utf-8') as f:
    for i in f:
        line = i.rstrip('\n').split()
        # type is string
        user_id = line[0]
        item_id = line[1]
        feedback = int(line[2])
        user_list.append(user_id)
        item_list.append(item_id)
        if user_id in inter_dict_x:
            inter_dict_x[user_id].append(item_id)
            inter_dict_y[user_id].append(feedback)
        else:
            inter_dict_x[user_id] = []
            inter_dict_y[user_id] = []
            inter_dict_x[user_id].append(item_id)
            inter_dict_y[user_id].append(feedback)

user_list = list(set(user_list))
item_list = list(set(item_list))

print(len(user_list))
print(len(item_list))

with open('interaction_dict_x.json', 'w') as g:
    json.dump(inter_dict_x, g)

with open('interaction_dict_y.json', 'w') as g:
    json.dump(inter_dict_y, g)

with open('user_list.json', 'w') as g:
    json.dump(user_list, g)

with open('item_list.json', 'w') as g:
    json.dump(item_list, g)